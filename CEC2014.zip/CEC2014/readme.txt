Please put cec14_func.cpp and input_data folder with your algorithm in the same folder. Set this folder as the current path.
get lower bound, upperbound, dimensions, function by calling the CEC2017.m file:
[lb,ub,dim,fobj] = CEC2014(function_name)

function name is from 'F1' to 'F30' as a string

